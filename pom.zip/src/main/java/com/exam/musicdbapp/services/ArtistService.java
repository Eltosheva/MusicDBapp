package com.exam.musicdbapp.services;

public interface ArtistService {
    void initArtistName();
}
