package com.exam.musicdbapp.services.Impl;

import com.exam.musicdbapp.model.entities.AlbumEntity;
import com.exam.musicdbapp.model.entities.UserEntity;
import com.exam.musicdbapp.model.service.AlbumServiceModel;
import com.exam.musicdbapp.repositories.AlbumRepository;
import com.exam.musicdbapp.repositories.ArtistNameRepository;
import com.exam.musicdbapp.services.AlbumService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AlbumServiceImpl implements AlbumService {

    private final AlbumRepository albumRepository;
    private final ModelMapper modelMapper;
    private final ArtistNameRepository artistNameRepository;

    public AlbumServiceImpl(AlbumRepository albumRepository, ModelMapper modelMapper, ArtistNameRepository artistNameRepository) {
        this.albumRepository = albumRepository;
        this.modelMapper = modelMapper;
        this.artistNameRepository = artistNameRepository;
    }

    @Override
    public void addAlbum(AlbumServiceModel albumServiceModel) {
        AlbumEntity albumEntity = modelMapper.map(albumServiceModel, AlbumEntity.class);
        albumEntity.setAddedFrom(modelMapper.map(albumServiceModel.getAddedFrom(), UserEntity.class));
        albumEntity.setArtist(artistNameRepository.findByName(albumServiceModel.getArtist()));
        albumEntity.setGenre(albumServiceModel.getGenre());
        albumRepository.save(albumEntity);
    }

    @Override
    public List<AlbumServiceModel> getAllAlbums() {
        return null;
    }

    @Override
    public void deleteAlbumById(String id) {
        albumRepository.deleteById(id);
    }
}
