package com.exam.musicdbapp.model.enums;

public enum AlbumGenreEnum {
    POP, ROCK, METAL, OTHER
}
