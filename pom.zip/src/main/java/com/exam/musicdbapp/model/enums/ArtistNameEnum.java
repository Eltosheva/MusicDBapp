package com.exam.musicdbapp.model.enums;

public enum ArtistNameEnum {
    QUEEN, METALLICA, MADONNA;

    private String id;

    public String getId() {
        return id;
    }

    public ArtistNameEnum setId(String id) {
        this.id = id;
        return this;
    }
}
