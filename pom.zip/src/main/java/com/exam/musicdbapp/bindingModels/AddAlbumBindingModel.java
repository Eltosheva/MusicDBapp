package com.exam.musicdbapp.bindingModels;

import com.exam.musicdbapp.model.enums.AlbumGenreEnum;
import com.exam.musicdbapp.model.enums.ArtistNameEnum;
import com.exam.musicdbapp.model.service.UserServiceModel;

import java.math.BigDecimal;
import java.time.LocalDate;

public class AddAlbumBindingModel {

    private String name;
    private String imageUrl;
    private String description;
    private int copies;
    private BigDecimal price;
    private LocalDate releacedDate;
    private String producer;
    private AlbumGenreEnum genre;
    private ArtistNameEnum artist;

    public AddAlbumBindingModel() {
    }

    public String getName() {
        return name;
    }

    public AddAlbumBindingModel setName(String name) {
        this.name = name;
        return this;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public AddAlbumBindingModel setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public AddAlbumBindingModel setDescription(String description) {
        this.description = description;
        return this;
    }

    public int getCopies() {
        return copies;
    }

    public AddAlbumBindingModel setCopies(int copies) {
        this.copies = copies;
        return this;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public AddAlbumBindingModel setPrice(BigDecimal price) {
        this.price = price;
        return this;
    }

    public LocalDate getReleacedDate() {
        return releacedDate;
    }

    public AddAlbumBindingModel setReleacedDate(LocalDate releacedDate) {
        this.releacedDate = releacedDate;
        return this;
    }

    public String getProducer() {
        return producer;
    }

    public AddAlbumBindingModel setProducer(String producer) {
        this.producer = producer;
        return this;
    }

    public AlbumGenreEnum getGenre() {
        return genre;
    }

    public AddAlbumBindingModel setGenre(AlbumGenreEnum genre) {
        this.genre = genre;
        return this;
    }

    public ArtistNameEnum getArtist() {
        return artist;
    }

    public AddAlbumBindingModel setArtist(ArtistNameEnum artist) {
        this.artist = artist;
        return this;
    }
}
