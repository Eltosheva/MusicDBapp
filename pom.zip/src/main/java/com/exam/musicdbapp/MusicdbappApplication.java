package com.exam.musicdbapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicdbappApplication {

    public static void main(String[] args) {
        SpringApplication.run(MusicdbappApplication.class, args);
    }

}
